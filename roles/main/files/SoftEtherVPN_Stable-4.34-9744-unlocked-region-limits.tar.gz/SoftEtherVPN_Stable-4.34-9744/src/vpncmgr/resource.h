//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vpncmgr.rc
//
#define IDI_ICON1                       101
#define IDI_VPN                         101
#define IDI_ICON2                       102
#define IDI_SERVER                      102
#define IDI_ICON3                       103
#define IDI_SERVER_OFF                  103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
